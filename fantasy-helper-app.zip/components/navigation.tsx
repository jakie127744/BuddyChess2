"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Trophy,
  BarChart3,
  Newspaper,
  ArrowLeftRight,
  Target,
  Users,
  Calendar,
  TrendingUp,
  Settings,
  GitCompare,
  FileText,
  Database,
} from "lucide-react"
import { cn } from "@/lib/utils"

const navItems = [
  { href: "/", label: "Home", icon: Trophy },
  { href: "/draft", label: "Draft Assistant", icon: BarChart3 },
  { href: "/lineup", label: "Lineup Optimizer", icon: Trophy },
  { href: "/stats", label: "Player Stats", icon: Newspaper },
  { href: "/trade", label: "Trade Analyzer", icon: ArrowLeftRight },
  { href: "/predictions", label: "Game Predictions", icon: Target },
  { href: "/compare", label: "Player Comparison", icon: GitCompare },
  { href: "/waiver", label: "Waiver Wire", icon: Users },
  { href: "/schedule", label: "Schedule Analyzer", icon: Calendar },
  { href: "/mock-draft", label: "Mock Draft", icon: TrendingUp },
  { href: "/playoff-odds", label: "Playoff Odds", icon: BarChart3 },
  { href: "/tips", label: "Roster Tips", icon: FileText },
  { href: "/matchups", label: "Matchup History", icon: Database },
  { href: "/settings", label: "League Settings", icon: Settings },
]

export function Navigation() {
  const pathname = usePathname()

  return (
    <nav className="border-b border-border bg-card">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Trophy className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-[family-name:var(--font-bebas)] text-2xl tracking-wide">FANTASY HUB</span>
          </Link>

          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary",
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                </Link>
              )
            })}
          </div>

          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 text-sm font-medium border border-border rounded-md hover:bg-secondary transition-colors">
              NBA
            </button>
            <button className="px-3 py-1.5 text-sm font-medium bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors">
              NFL
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="md:hidden flex items-center gap-1 overflow-x-auto pb-3 -mx-4 px-4">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary",
                )}
              >
                <Icon className="w-3.5 h-3.5" />
                {item.label}
              </Link>
            )
          })}
        </div>
      </div>
    </nav>
  )
}

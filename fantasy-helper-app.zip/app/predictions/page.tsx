import { Target, TrendingUp, TrendingDown, Activity } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"

export default function PredictionsPage() {
  const upcomingGames = [
    {
      id: 1,
      homeTeam: "Lakers",
      awayTeam: "Warriors",
      homeScore: 112,
      awayScore: 108,
      confidence: 72,
      spread: -3.5,
      overUnder: 220.5,
      time: "Tonight 7:30 PM",
      keyFactors: ["Lakers 7-2 at home", "Warriors on back-to-back", "LeBron questionable"],
    },
    {
      id: 2,
      homeTeam: "Celtics",
      awayTeam: "Heat",
      homeScore: 118,
      awayScore: 110,
      confidence: 68,
      spread: -6.5,
      overUnder: 228.5,
      time: "Tonight 8:00 PM",
      keyFactors: ["Celtics elite defense", "Heat missing Butler", "Boston 9-1 last 10"],
    },
    {
      id: 3,
      homeTeam: "Nuggets",
      awayTeam: "Suns",
      homeScore: 121,
      awayScore: 115,
      confidence: 65,
      spread: -4.5,
      overUnder: 236.5,
      time: "Tonight 9:00 PM",
      keyFactors: ["Jokic averaging triple-double", "Altitude advantage", "Suns 2-5 on road"],
    },
    {
      id: 4,
      homeTeam: "Chiefs",
      awayTeam: "Bills",
      homeScore: 27,
      awayScore: 24,
      confidence: 58,
      spread: -2.5,
      overUnder: 51.5,
      time: "Sunday 4:25 PM",
      keyFactors: ["Mahomes playoff experience", "Bills strong pass rush", "Weather: Clear"],
    },
    {
      id: 5,
      homeTeam: "49ers",
      awayTeam: "Eagles",
      homeScore: 31,
      awayScore: 28,
      confidence: 63,
      spread: -3.5,
      overUnder: 49.5,
      time: "Sunday 1:00 PM",
      keyFactors: ["CMC rushing threat", "Eagles secondary injuries", "Home field edge"],
    },
    {
      id: 6,
      homeTeam: "Cowboys",
      awayTeam: "Packers",
      homeScore: 24,
      awayScore: 20,
      confidence: 55,
      spread: -1.5,
      overUnder: 44.5,
      time: "Sunday 4:25 PM",
      keyFactors: ["Cowboys defense ranked 3rd", "Love inconsistent on road", "Even matchup"],
    },
  ]

  const trendingPicks = [
    { team: "Lakers", pickRate: 78, movement: "up" },
    { team: "Celtics", pickRate: 82, movement: "up" },
    { team: "Chiefs", pickRate: 65, movement: "down" },
    { team: "49ers", pickRate: 71, movement: "up" },
  ]

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Target className="w-6 h-6 text-primary-foreground" />
              </div>
              <h1 className="font-[family-name:var(--font-bebas)] text-5xl tracking-wide">GAME PREDICTIONS</h1>
            </div>
            <p className="text-muted-foreground">
              AI-powered predictions for upcoming NBA and NFL games with confidence ratings
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-4">
              {upcomingGames.map((game) => {
                const isHomeWinner = game.homeScore > game.awayScore
                const isNFL = ["Chiefs", "Bills", "49ers", "Eagles", "Cowboys", "Packers"].includes(game.homeTeam)

                return (
                  <Card key={game.id} className="p-6 hover:border-primary transition-colors">
                    <div className="flex items-start justify-between mb-4">
                      <Badge variant="secondary" className="text-xs">
                        {isNFL ? "NFL" : "NBA"}
                      </Badge>
                      <span className="text-sm text-muted-foreground">{game.time}</span>
                    </div>

                    {/* Teams and Scores */}
                    <div className="space-y-3 mb-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center font-bold">
                            {game.awayTeam.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-semibold text-lg">{game.awayTeam}</div>
                            <div className="text-xs text-muted-foreground">Away</div>
                          </div>
                        </div>
                        <div
                          className={`text-3xl font-bold font-[family-name:var(--font-bebas)] ${!isHomeWinner ? "text-primary" : "text-muted-foreground"}`}
                        >
                          {game.awayScore}
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center font-bold">
                            {game.homeTeam.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-semibold text-lg">{game.homeTeam}</div>
                            <div className="text-xs text-muted-foreground">Home</div>
                          </div>
                        </div>
                        <div
                          className={`text-3xl font-bold font-[family-name:var(--font-bebas)] ${isHomeWinner ? "text-primary" : "text-muted-foreground"}`}
                        >
                          {game.homeScore}
                        </div>
                      </div>
                    </div>

                    {/* Betting Lines */}
                    <div className="grid grid-cols-3 gap-3 mb-4 p-3 bg-secondary rounded-lg">
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">Spread</div>
                        <div className="font-semibold">{game.spread}</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">Over/Under</div>
                        <div className="font-semibold">{game.overUnder}</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">Confidence</div>
                        <div className="font-semibold text-primary">{game.confidence}%</div>
                      </div>
                    </div>

                    {/* Key Factors */}
                    <div>
                      <div className="text-sm font-medium mb-2">Key Factors</div>
                      <div className="flex flex-wrap gap-2">
                        {game.keyFactors.map((factor, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {factor}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </Card>
                )
              })}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Prediction Stats */}
              <Card className="p-6">
                <h3 className="font-[family-name:var(--font-bebas)] text-2xl tracking-wide mb-4">PREDICTION STATS</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-sm">Today's Games</span>
                    <span className="font-bold text-xl">{upcomingGames.length}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-sm">Avg Confidence</span>
                    <span className="font-bold text-xl text-primary">64%</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <span className="text-sm">Last Week Accuracy</span>
                    <span className="font-bold text-xl text-primary">71%</span>
                  </div>
                </div>
              </Card>

              {/* Trending Picks */}
              <Card className="p-6">
                <h3 className="font-[family-name:var(--font-bebas)] text-2xl tracking-wide mb-4">TRENDING PICKS</h3>
                <div className="space-y-3">
                  {trendingPicks.map((pick) => (
                    <div key={pick.team} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                      <div className="flex items-center gap-2">
                        {pick.movement === "up" ? (
                          <TrendingUp className="w-4 h-4 text-primary" />
                        ) : (
                          <TrendingDown className="w-4 h-4 text-destructive" />
                        )}
                        <span className="font-medium">{pick.team}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">{pick.pickRate}%</span>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Prediction Tips */}
              <Card className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Activity className="w-5 h-5 text-primary" />
                  <h3 className="font-[family-name:var(--font-bebas)] text-2xl tracking-wide">PREDICTION TIPS</h3>
                </div>
                <div className="space-y-3 text-sm text-muted-foreground">
                  <p>Predictions update every hour with latest injury reports and line movements</p>
                  <p>Confidence ratings above 70% have historically won 78% of the time</p>
                  <p>Home teams tend to outperform by 3-4 points on average</p>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

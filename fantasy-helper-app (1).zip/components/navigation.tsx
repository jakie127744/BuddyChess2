"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"
import {
  Trophy,
  BarChart3,
  Newspaper,
  ArrowLeftRight,
  Target,
  Users,
  Calendar,
  TrendingUp,
  Settings,
  GitCompare,
  FileText,
  Database,
  Menu,
  X,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

const navItems = [
  { href: "/", label: "Home", icon: Trophy },
  { href: "/draft", label: "Draft Assistant", icon: BarChart3 },
  { href: "/lineup", label: "Lineup Optimizer", icon: Trophy },
  { href: "/stats", label: "Player Stats", icon: Newspaper },
  { href: "/trade", label: "Trade Analyzer", icon: ArrowLeftRight },
  { href: "/predictions", label: "Game Predictions", icon: Target },
  { href: "/compare", label: "Player Comparison", icon: GitCompare },
  { href: "/waiver", label: "Waiver Wire", icon: Users },
  { href: "/schedule", label: "Schedule Analyzer", icon: Calendar },
  { href: "/mock-draft", label: "Mock Draft", icon: TrendingUp },
  { href: "/playoff-odds", label: "Playoff Odds", icon: BarChart3 },
  { href: "/tips", label: "Roster Tips", icon: FileText },
  { href: "/matchups", label: "Matchup History", icon: Database },
  { href: "/settings", label: "League Settings", icon: Settings },
]

export function Navigation() {
  const pathname = usePathname()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <nav className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Trophy className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-[family-name:var(--font-bebas)] text-xl sm:text-2xl tracking-wide">FANTASY HUB</span>
          </Link>

          {/* Desktop Navigation - Hidden on mobile/tablet */}
          <div className="hidden lg:flex items-center gap-1 overflow-x-auto">
            {navItems.slice(0, 6).map((item) => {
              const Icon = item.icon
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary",
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                </Link>
              )
            })}
          </div>

          {/* Right Side - League Switchers & Hamburger */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <button className="px-3 py-1.5 text-xs sm:text-sm font-medium border border-border rounded-md hover:bg-secondary transition-colors">
                NBA
              </button>
              <button className="px-3 py-1.5 text-xs sm:text-sm font-medium bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors">
                NFL
              </button>
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-background/80 backdrop-blur-sm lg:hidden"
            onClick={() => setMobileMenuOpen(false)}
          />

          {/* Slide-out menu */}
          <div className="fixed top-16 right-0 bottom-0 w-80 max-w-[85vw] bg-card border-l border-border overflow-y-auto lg:hidden shadow-xl">
            <div className="p-4 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={cn(
                      "flex items-center gap-3 px-4 py-3 rounded-lg text-base font-medium transition-colors",
                      isActive
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground hover:bg-secondary",
                    )}
                  >
                    <Icon className="w-5 h-5" />
                    {item.label}
                  </Link>
                )
              })}
            </div>
          </div>
        </>
      )}
    </nav>
  )
}
